import pytest

@pytest.fixture(scope='module')
def any_name():
    print('\nsetup') # arrange / setup
    yield 5 # or return if no teardown needed
    print('teardown') # cleanup / teardown

def test_a(any_name):
    print('do something') # act
    print('assert something') # assert
    assert any_name == 5

def test_b(any_name):
    print('do something') # act
    print('assert something') # assert
    assert any_name == 5