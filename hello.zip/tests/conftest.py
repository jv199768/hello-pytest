import hello 
import pytest

@pytest.fixture(scope='module')
def hello_result():
    "returns full output with no cli args"
    return hello.full_output()
