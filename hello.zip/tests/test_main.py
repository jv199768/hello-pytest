import hello 
import pytest

# application tests
@pytest.mark.smoke
def test_main(capsys):
    hello.main()
    result = capsys.readouterr().out.rstrip()
    assert result == "Hello, World!"
