import hello 
import pytest


@pytest.mark.smoke
def test_hello(hello_result):
    assert hello_result == "Hello, World!"


@pytest.mark.parametrize('arg_str, expected', [
    ("-g Hey", "Hey, World!"), 
    ("--greeting Hey", "Hey, World!"),
    ("-n Brian", "Hello, Brian!"), 
    ("--name Brian", "Hello, Brian!"), 
    pytest.param("-g Hey -n Brian", "Hey, Brian!", marks=pytest.mark.smoke),
    ], ids=(lambda x : f"'{x}'"))
def test_output(arg_str, expected):
    result = hello.full_output(arg_str)
    assert result == expected